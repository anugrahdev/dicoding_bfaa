package com.anugrahdev.bffasubmission2.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.anugrahdev.bffasubmission2.databinding.ItemFollowItemBinding
import com.anugrahdev.bffasubmission2.databinding.ItemUsersBinding
import com.anugrahdev.bffasubmission2.models.followthing.FollowItems
import com.anugrahdev.bffasubmission2.models.search.ItemsUser

class FollowViewHolder(val binding: ItemFollowItemBinding): RecyclerView.ViewHolder(binding.root) {

    fun bind(model: FollowItems) {
        binding.user = model
        binding.executePendingBindings()
    }

    companion object {
        fun from(parent: ViewGroup): FollowViewHolder {
            val inflater = LayoutInflater.from(parent.context)
            val binding: ItemFollowItemBinding = ItemFollowItemBinding.inflate(inflater, parent, false)
            return FollowViewHolder(binding)
        }
    }
}