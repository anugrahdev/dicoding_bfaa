package com.anugrahdev.bffasubmission2.data

const val BASE_URL:String = "https://api.github.com/"
const val ACCESS_TOKEN = "1bbf4f1a01e667d56d6aaeaf267cc44299d8330f"

