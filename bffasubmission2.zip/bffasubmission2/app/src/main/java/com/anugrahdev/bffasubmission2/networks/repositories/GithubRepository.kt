package com.anugrahdev.bffasubmission2.networks.repositories

import com.anugrahdev.bffasubmission2.models.followthing.FollowItems
import com.anugrahdev.bffasubmission2.models.profile.Users
import com.anugrahdev.bffasubmission2.models.search.ItemsUser
import com.anugrahdev.bffasubmission2.networks.SafeApiRequest
import com.anugrahdev.bffasubmission2.networks.ServiceFactory
import com.anugrahdev.bffasubmission2.networks.restapi.RestApiGithub
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class GithubRepository (private val scope: CoroutineScope) : SafeApiRequest() {
    private val restApi = ServiceFactory.getApiService(RestApiGithub::class.java)

    fun getSearchUsers(
        query:String,
        onSuccess: (List<ItemsUser>?) -> Unit,
        onError: (Exception) -> Unit,
    ) {
        scope.launch {
            delay(1500L)
            try {
                val result = apiRequest { restApi.getSearchUsers(query) }
                onSuccess(result?.items)
            } catch (e: Exception) {
                onError(e)
            }
        }
    }

    fun getUser(
        username:String,
        onSuccess: (Users?) -> Unit,
        onError: (Exception) -> Unit,
    ) {
        scope.launch {
            try {
                val result = apiRequest { restApi.getUser(username) }
                onSuccess(result)
            } catch (e: Exception) {
                onError(e)
            }
        }
    }

    fun getFollowers(
        username:String,
        onSuccess: (List<FollowItems>?) -> Unit,
        onError: (Exception) -> Unit,
    ) {
        scope.launch {
            try {
                val result = apiRequest { restApi.getUserFollowers(username) }
                onSuccess(result)
            } catch (e: Exception) {
                onError(e)
            }
        }
    }

    fun getFollowing(
        username:String,
        onSuccess: (List<FollowItems>?) -> Unit,
        onError: (Exception) -> Unit,
    ) {
        scope.launch {
            try {
                val result = apiRequest { restApi.getUserFollowing(username) }
                onSuccess(result)
            } catch (e: Exception) {
                onError(e)
            }
        }
    }

}